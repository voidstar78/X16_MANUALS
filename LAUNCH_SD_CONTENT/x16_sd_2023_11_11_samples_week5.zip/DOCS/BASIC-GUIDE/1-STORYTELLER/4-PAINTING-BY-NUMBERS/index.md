# Chapter 1-4: Painting by Numbers

1. [Lines](LINES.BAS)
2. [Boxes](BOXES.BAS)
3. [Mandelbrot](MANDELBROT.BAS)
