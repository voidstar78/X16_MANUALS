# basic-adventures-moss
Materials for the Book "BASIC Adventures with Professor Moss"

## [Level 1: Storyteller](1-STORYTELLER/index.md)
### [Chapter 1: Greetings and Salutations](1-STORYTELLER/1-GREETINGS-AND-SALUTATIONS/index.md)
### [Chapter 2: The Call to Adventure](1-STORYTELLER/2-THE-CALL-TO-ADVENTURE/index.md)
### [Chapter 3: Random Chaos](1-STORYTELLER/3-RANDOM-CHAOS/index.md)
### [Chapter 4: Painting by Numbers](1-STORYTELLER/4-PAINTING-BY-NUMBERS/index.md)
### [Chapter 5: Telling Tales](1-STORYTELLER/5-TELLING-TALES/index.md)

## [Level 2: Programmer](2-PROGRAMMER/index.md)
### [Chapter 1: Bits and Bytes](2-PROGRAMMER/1-GREETINGS-AND-SALUTATIONS/index.md)
### [Chapter 2: Getting the Band Back Together](2-PROGRAMMER/2-GETTING-THE-BAND-BACK-TOGETHER/index.md)
### [Chapter 3: Reading the Scrolls](2-PROGRAMMER/3-READING-THE-SCROLLS/index.md)
### [Chapter 4: Cycles of the Stars](2-PROGRAMMER/4-CYCLES-OF-THE-STARS/index.md)
### [Chapter 5: To the Moon](2-PROGRAMMER/5-TO-THE-MOON/index.md)

## [Level 3: Engineer](3-ENGINEER/index.md)
### [Chapter 1: Simulation of Life](3-ENGINEER/1-SIMULATION-OF-LIFE/index.md)
### [Chapter 2: Robot Friend](3-ENGINEER/2-ROBOT-FRIEND/index.md)
### [Chapter 3: Colonel Vera](3-ENGINEER/3-COLONEL-VERA/index.md)
### [Chapter 4: The Real World](3-ENGINEER/4-THE-REAL-WORLD/index.md)
### [Chapter 5: The Analog Rebellion](3-ENGINEER/5-THE-ANALOG-REBELLION/index.md)
