# Chapter 1-3: Random Chaos

1. [Guessing Game](GUESSING-GAME.BAS)
2. [Maze](MAZE.BAS)
3. [Shuffle Cards](SHUFFLE-CARDS.BAS)
4. [Number Generator Statistics](NUM-GEN-STAT.BAS)
