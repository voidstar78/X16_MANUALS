This will be the root of the demo jukebox's media folders.

No submissions into this folder please!

