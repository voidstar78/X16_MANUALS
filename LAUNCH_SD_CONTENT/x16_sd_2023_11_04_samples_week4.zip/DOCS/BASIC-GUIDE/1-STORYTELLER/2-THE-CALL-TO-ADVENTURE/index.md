# Chapter 1-2: The Call to Adventure

1. [Chorale](CHORALE.BAS)
2. [Knock-Knock Joke](KNOCK.BAS)
3. [Hunterbot](HUNTERBOT.BAS)
4. [Count GOTO](COUNT-GOTO.BAS)
5. [Count FOR](COUNT-FOR.BAS)
6. [Siren](SIREN.BAS)
