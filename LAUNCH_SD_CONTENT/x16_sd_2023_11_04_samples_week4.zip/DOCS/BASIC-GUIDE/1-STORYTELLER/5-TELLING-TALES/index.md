# Chapter 1-5: Telling Tales

1. [Ascendency of the Scholar](ASCENDENCY-SCHOLAR.BAS)
2. [Sea Scoundrels](SEA-SCOUNDRELS.BAS)
3. [The Eternal Ember](ETERNAL-EMBER.BAS)
4. [The Alchemist's Enigma](ALCHEMIST-ENIGMA.BAS)
5. [Outlaw Justice](OUTLAW-JUSTICE.BAS)
