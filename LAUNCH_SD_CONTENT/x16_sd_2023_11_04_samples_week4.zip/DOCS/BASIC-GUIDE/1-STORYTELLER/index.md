# Level 1: Storyteller
## [Chapter 1: Greetings and Salutations](1-GREETINGS-AND-SALUTATIONS/index.md)
## [Chapter 2: The Call to Adventure](2-THE-CALL-TO-ADVENTURE/index.md)
## [Chapter 3: Random Chaos](3-RANDOM-CHAOS/index.md)
## [Chapter 4: Painting by Numbers](4-PAINTING-BY-NUMBERS/index.md)
## [Chapter 5: Telling Tales](5-TELLING-TALES/index.md)
